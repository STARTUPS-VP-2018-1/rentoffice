/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.rentoffice.business;

import br.com.rentoffice.dominio.Locatario;
import java.util.List;
import br.com.rentoffice.business.interfaces.LocatarioInterface;
import br.com.rentoffice.repositorio.Repositorio;


public class LocatarioBusiness implements LocatarioInterface{
       
   
    public Locatario buscarLocatarioPorEmail(List email) {
        for(Locatario locatario: Repositorio.locatarioDBFake){
            if(locatario.getEmails() == email){
                return locatario;
            }
        } 
        return null;
    }

    public List<Locatario> buscarClientePorNome(String nome) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
 
    public List<Locatario> buscarTodosLocatarios() {
        return Repositorio.locatarioDBFake;
    }

    @Override
    public Locatario salvarLocatario(Locatario cliente) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public List<Locatario> buscarLocatarioPorNome(String nome) {
                 for(Locatario locatario: Repositorio.locatarioDBFake){
            if(locatario.getNome() == nome){
                return (List<Locatario>) locatario;
            }
        } 
        return null;
    }


    public List<Locatario> buscarLocatarioPorCNPJ(String CNPJ) {
         for(Locatario locatario: Repositorio.locatarioDBFake){
            if(locatario.getCNPJ() == CNPJ){
                return (List<Locatario>) locatario;
            }
        } 
        return null;
    }

    @Override
    public List<Locatario> buscarLocatarioPorCNPJ() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    }
